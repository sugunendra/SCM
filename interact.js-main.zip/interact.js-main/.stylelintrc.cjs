module.exports = {
  extends: ['stylelint-config-standard', 'stylelint-config-recess-order', 'stylelint-config-css-modules'],
  ignoreFiles: ['dist/**/*', 'coverage/**/*'],
}
