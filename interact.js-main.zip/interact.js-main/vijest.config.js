module.exports = {
  launch: {
    executablePath: 'chromium',
    // devtools: true,
    // slowMo: 1000,
  },
  shareBrowserContext: true,
}
