export { default } from '../noop'
