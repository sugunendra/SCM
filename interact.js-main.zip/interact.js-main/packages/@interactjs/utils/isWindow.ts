export default (thing: any) => !!(thing && thing.Window) && thing instanceof thing.Window
