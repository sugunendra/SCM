export const NativePointerEvent = null as unknown as InstanceType<typeof PointerEvent>
export type NativeEventTarget = EventTarget
export type NativeElement = Element
