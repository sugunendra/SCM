<h2>
This package is an internal part of <a
href="https://www.npmjs.com/package/interactjs">interactjs</a> and is not meant
to be used independently as each update may introduce breaking changes
</h2>
