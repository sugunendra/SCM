module.exports = {
  extends: '../.eslintrc.cjs',
  env: { browser: true },
  rules: { 'no-console': 2, strict: [2, 'never'] },
}
