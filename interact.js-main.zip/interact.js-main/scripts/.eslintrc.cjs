module.exports = {
  extends: '../.eslintrc.cjs',
  parserOptions: { sourceType: 'script', ecmaVersion: 2018 },
  rules: { 'import/no-extraneous-dependencies': 'off' },
}
